import { computeTotal, getProduct } from "@/lib/catalog";
import { notifyAboutOrder } from "@/lib/telegram-notify";

export const dynamic = "force-dynamic";

interface IncomingItem { id: string; qty: number; }

function sanitizeItems(raw: unknown): IncomingItem[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((item) => ({
      id: String((item as IncomingItem)?.id ?? ""),
      qty: Math.max(0, Math.min(99, Math.floor(Number((item as IncomingItem)?.qty) || 0))),
    }))
    .filter((item) => item.id && getProduct(item.id) && item.qty > 0)
    .slice(0, 50);
}

export async function GET() {
  return Response.json({ ok: true, orders: [] });
}

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "bad_json" }, { status: 400 });
  }

  const userId = String(body.userId ?? "").slice(0, 64);
  const customerName = String(body.customerName ?? "").trim().slice(0, 120);
  const phone = String(body.phone ?? "").trim().slice(0, 32);
  const comment = String(body.comment ?? "").trim().slice(0, 500);
  const username = String(body.username ?? "").slice(0, 64) || null;
  const items = sanitizeItems(body.items);

  if (!userId || !customerName || !phone || items.length === 0) {
    return Response.json({ ok: false, error: "validation" }, { status: 422 });
  }

  const total = computeTotal(items);
  if (total <= 0) return Response.json({ ok: false, error: "empty_total" }, { status: 422 });

  const stored = items.map((item) => {
    const product = getProduct(item.id)!;
    return { id: product.id, name: product.name, price: product.price, qty: item.qty };
  });

  const id = Math.floor(Date.now() / 1000);
  await notifyAboutOrder({
    id, customerName, phone, comment: comment || null, username, items: stored, total, userId,
  });

  return Response.json({ ok: true, order: { id, total, createdAt: new Date().toISOString() } }, { status: 201 });
}
